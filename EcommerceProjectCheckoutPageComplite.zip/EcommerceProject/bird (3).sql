-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2021 at 08:21 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bird`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `customer_ip`, `product_id`, `product_quantity`, `created_at`, `updated_at`) VALUES
(8, '127.0.0.1', 6, 7, '2021-04-16 02:17:00', '2021-04-25 00:41:02'),
(9, '127.0.0.1', 5, 5, '2021-04-16 02:17:10', '2021-04-25 00:41:03');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_id`, `created_at`, `updated_at`) VALUES
(4, 'Web Design', '2021-04-03 12:19:49', NULL),
(5, 'web Development', '2021-04-03 12:20:07', NULL),
(6, 'App Development', '2021-04-03 12:22:57', NULL),
(7, 'Paython', '2021-04-03 12:31:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `coupon_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_percentage` int(11) NOT NULL,
  `valid_till` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `coupon_name`, `coupon_percentage`, `valid_till`, `created_at`, `updated_at`) VALUES
(1, 'EID20', 20, '2021-04-17 18:00:00', NULL, NULL),
(2, 'EID21', 20, '2021-04-15 18:00:00', NULL, NULL),
(3, 'EID202', 20, '2021-04-15 18:00:00', NULL, NULL),
(4, 'EID20222', 20, '2021-04-16 18:00:00', NULL, NULL),
(5, 'EID202211', 20, '2021-05-20 18:00:00', NULL, NULL),
(6, 'EID2022', 100, '2021-04-17 09:00:07', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customerprofile`
--

CREATE TABLE `customerprofile` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `Company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ZipCode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PhoneNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customerprofile`
--

INSERT INTO `customerprofile` (`id`, `user_id`, `Company`, `address`, `ZipCode`, `PhoneNumber`, `created_at`, `updated_at`) VALUES
(4, 7, 'Auro Cafe BD Ltdjosim', 'Luxmipur Rajshahi', '6000', '01793681692', '2021-04-24 00:09:26', '2021-04-24 00:09:26');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(6, '2021_04_03_174519_create_categories_table', 3),
(7, '2021_03_30_100957_create_products_table', 4),
(8, '2021_04_15_163542_cart', 5),
(9, '2021_04_16_182612_coupons', 6),
(10, '2021_04_24_044613_customer_profile', 7);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_p_id` int(11) NOT NULL,
  `Product_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Product_Description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Product_Price` int(11) NOT NULL,
  `Product_Quentity` int(11) NOT NULL,
  `Product_Alert_Quentity` int(11) NOT NULL,
  `Product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'defaultproductphoto.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_p_id`, `Product_Name`, `Product_Description`, `Product_Price`, `Product_Quentity`, `Product_Alert_Quentity`, `Product_image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 'web design', 'vxvbd', 15, 21, 5, 'defaultproductphoto.jpg', NULL, '2021-04-04 12:14:34', NULL),
(2, 7, 'পাইথন', 'েরর', 120, 14, 2, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(3, 5, 'josim', 'fbbsh', 1550, 14, 25488, '3.jpg', NULL, '2021-04-04 02:44:58', NULL),
(4, 6, 'মো:জসিম উদ্দীন', 'kkjj', 120, 2, 1, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(5, 7, 'পাইথন', 'xbfvbb', 2, 120, 5, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(6, 4, 'মো:জসিম উদ্দীন', 'dvdv', 1550, 100, 25488, '6.jpg', NULL, '2021-04-04 12:13:40', NULL),
(7, 7, 'মো:জসিম উদ্দীন', 'vgfn', 15, 21, 5, '7.png', NULL, '2021-04-04 12:57:57', '2021-04-04 12:57:57'),
(8, 4, 'Riajul', 'dbhn', 120, 92, 5, '8.jpg', NULL, '2021-04-15 11:49:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL DEFAULT 1,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `role`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 1, 'admin@gmail.com', NULL, '$2y$10$5CflgXCF8ZcicXHJHRW.vOpIwA86VWNgtCIGYT7Wp1Hk4UueFiTIO', 'QHooCZXh3eNyX3lawI0333rTzvcl3LIgqTm7Pv8sbtOLBwshu54zr8oOKYZp', '2021-03-30 03:46:02', '2021-03-30 03:46:02'),
(2, 'Md. Abdur Rahman', 1, 'aurocafe4@gmail.com', NULL, '$2y$10$exXKDQdnLnfcj2jPW9Fp4ups6vW77b56O4CjGVf0/.lkWTwO.KGCS', NULL, '2021-04-21 23:27:02', NULL),
(4, 'nmbh', 1, 'aurocafe44@gmail.com', NULL, '$2y$10$sTmIM.o/HyOEtWTeaRhD6O4yWEDkUi3uPOkug6oMuw4D.1LOekvTO', NULL, '2021-04-21 23:28:39', NULL),
(5, 'josim', 2, 'vai@gmail.com', NULL, '$2y$10$us5FGLSIJZk6u.LO360NLunv6/jNsqIZN5Tw5uXHLxF5hC7CcnUQe', NULL, '2021-04-21 23:30:55', NULL),
(6, 'Md. Abdur Rahman', 2, 'aurocafe554@gmail.com', NULL, '$2y$10$NvxWAxWEYspXmNZnBLC3LuGccNDddVirG0s/a1SG3oRZeSCKGQNbu', NULL, '2021-04-22 04:14:50', NULL),
(7, 'Josim Uddin', 2, 'josimuddin228586@gmail.com', NULL, '$2y$10$SQhtjJUBxPFfQyZJPv/6EuWbQyN.wvDJKBmp8V0fXpBI3rSK/41hS', NULL, '2021-04-22 22:48:59', '2021-04-23 13:23:24'),
(8, 'Josim Uddin', 2, 'josimcmtinfo@gmail.com', NULL, 'SocialAcount', NULL, '2021-04-22 22:54:03', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customerprofile`
--
ALTER TABLE `customerprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customerprofile`
--
ALTER TABLE `customerprofile`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
