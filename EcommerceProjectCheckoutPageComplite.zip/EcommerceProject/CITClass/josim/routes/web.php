<?php



// Route::get('/', function () {
//     return view('welcome');
// });



// FrontEnd Route Section

Route::get('/','FrontendHomeController@Frontendhome');
// Click কারার পরে product Details Single Page এ দেখানোর জনে
Route::get('/product/Details/{product_id}','FrontendHomeController@productDetails');
// ডাটা cart এ Insert কারার জনে
Route::get('/add/to/cart/{product_id}','FrontendHomeController@addtocart');

//  cart a click করলে Cart Page কে দেখানোর জনে
Route::get('/cart','FrontendHomeController@cart');
// coupon_name এর মাধমে যে input টা দিব তাকে ধরে দেখাবে এবং Controller এ কোড আপডেট করতে হবে
Route::get('/cart/{coupon_name}','FrontendHomeController@cart');
//  Specifick কোন cart এ যুকত করা ডাটাকে ডিলিট করা জনে 
Route::get('/delete/from/cart/{cart_id}','FrontendHomeController@deletefromcart');
//  IP অনুযায়ী তার সকল cart এ যুকত করা  ডাটা কে ডিলিট করার জনে 
Route::get('/clear/cart','FrontendHomeController@clearcart');

// cart এর product গুলো কে আপডেট করার জনে
Route::post('/update/cart','FrontendHomeController@updatecart');




Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');




// Backend Route Section

// Product Route
Route::get('/Add/Product/View','ProductController@index');
Route::post('/add/product/insert','ProductController@addproductinsert');
// Delete Route
Route::get('/delete/product/{product_id}','ProductController@deleteproduct');
// Edit করার সময় ডাটাগুলা শো করার জনে Route
Route::get('/edit/product/{product_id}','ProductController@editproduct');
// Edit করে ডাটা যুকত করার জনে
Route::post('/edit/product/insert','ProductController@editproductinsert');
// ডিলিট করা ডাটাগুলে Restor করার জনে
Route::get('/restore/product/{product_id}','ProductController@restore_product');
// ডিলিট করা ডাটাগুলে Permantly Delete করার জনে
Route::get('/permantlyDelete/product/{product_id}','ProductController@permantlyDeleteProduct');


// Category Route Section

Route::get('/Add/category/View','CategoriesController@index');
Route::post('/add/category/insert','CategoriesController@addcategoryinsert');


// Archive  Route

Route::get('category/wise/product/{category_id}','FrontendHomeController@categorywiseproduct');


// Coupons Add করার জনে

Route::get('/Add/coupon/View', 'CouponController@AddcouponView');
Route::post('/add/coupon/insert', 'CouponController@addcouponinsert');



// Customer Login এর জনে
Route::get('/registation/view','FrontendHomeController@registationview');
// Customer এর ডাটা Insert করার জন্যে
Route::post('/Customer/insert','FrontendHomeController@Customerinsert');
// এর মাধ্যমে customer কে তার Dashbord এ নিয়ে যাবে
Route::get('customer/dashbord','CustomerController@Customerhome');


// GitHub Login system

Route::get('login/google', 'GithubController@redirectToProvider');
Route::get('login/google/callback', 'GithubController@handleProviderCallback');


// কাস্টমার Dashbord এ ঢুকার পরে চেক হবে যে সে কি দিয়ে লগিন করেছে SocialMedia না হাতে লিখে
// SocialMedia Login set password
Route::post('set/password', 'CustomerController@setpassword');

// Hand Registation or password যদি socialmedia না হয় তাহলে

Route::post('Change/password', 'CustomerController@Changepassword');

// My Profile এর রাউট 
Route::get('my/profile', 'CustomerController@myprofile');
// Customer Profile এর ডাটাকে ডাটাবেসে ঢুকানো
Route::post('my/profile/insert', 'CustomerController@myprofileinsert');
Route::post('my/profile/update', 'CustomerController@myprofileupdate');


// Proces To CheckOut Pge Work

Route::post('checkout', 'checkoutController@checkout');