<?php $__env->startSection('title','ProductDetails'); ?>
<?php $__env->startSection('content'); ?>


<div class="page-info-section page-info">
<div class="container">
<div class="site-breadcrumb">
<a href="<?php echo e(url('/')); ?>">Home</a> /
<span><?php echo e($single_product_info->Product_Name); ?></span>
</div>
<img src="<?php echo e(asset('frontend/img/page-info-art.png')); ?>" alt="" class="page-info-art">
</div>
</div>





<div class="container mt-5">
	<div class="row">
		<div class="col-lg-6">
			<div class="single_product_img">
				<img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($single_product_info->Product_image); ?>">
				
			</div>
			
		</div>
		<div class="col-lg-6">
			<div class="row">
				<div class="product_single_content">
					<h2><?php echo e($single_product_info->Product_Name); ?></h2>
          
          <!-- <?php echo e($single_product_info->relationtocategory->category_id); ?>

          এর মাধমে single post টা কোন category তা দেখানো হলো তার আগে Model এর
          সাথে Model এর রিলেশন করে Dashbord এ category Name দেখাতে হবে -->

          <h3><?php echo e($single_product_info->relationtocategory->category_id); ?></h3>
					<span>$<?php echo e($single_product_info->Product_Price); ?></span>
					<span>
						<i class="fa fa-star" aria-hidden="true"></i>
						<i class="fa fa-star" aria-hidden="true"></i>
						<i class="fa fa-star" aria-hidden="true"></i>
						<i class="fa fa-star-half-o" aria-hidden="true"></i>
					</span>
					<p><?php echo e($single_product_info->Product_Description); ?></p>
          <?php if($single_product_info->Product_Quentity > 0): ?>
					<a href="<?php echo e(url('add/to/cart')); ?>/<?php echo e($single_product_info->id); ?>" class="btn btn-outline-primary">Add To Cart</a>
          <?php else: ?>
			<div class="alert alert-danger">
				No Product Available
				
			</div>
			<?php endif; ?>
				</div>
				
			</div>
			
		</div>
		
	</div>

	<div class="row">
		<div class="col-lg-12">
<h2 class="text-center mb-5 mt-5">Product Description</h2>
	

		
	</div>
	
	<div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
         Description
        </button>
      </h5>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Additional Information
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Review
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
</div>

</div>



<div class="row">
<div class="col-lg-12">
<h2 class="text-center mb-5 mt-5">Related Product</h2>
	
</div>

 <!-- রিলেটেড Product দেখানোর জনে -->

<?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-lg-3">
    <div class="card mb-5">
      <img src="<?php echo e(asset('frontend/img/intro/5.jpg')); ?>">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($related_product->Product_Name); ?></h5>
            <span>$<?php echo e($related_product->Product_Price); ?></span>
        <a href="<?php echo e(url('/product/Details')); ?>/<?php echo e($related_product->id); ?>"><button type="button" class="btn btn-outline-primary">Add To Cart</button></a>

      </div>

    </div>
		
	</div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




	
</div>


</div>




<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim Uddin\Desktop\CITClass\josim\resources\views/frontend/Show_Single_product.blade.php ENDPATH**/ ?>