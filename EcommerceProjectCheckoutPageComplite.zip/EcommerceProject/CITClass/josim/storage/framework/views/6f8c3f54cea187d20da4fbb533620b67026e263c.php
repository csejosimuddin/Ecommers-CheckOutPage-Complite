<?php $__env->startSection('content'); ?>

<!-- কাস্টমার Dashbord এ ঢুকার পরে চেক হবে যে সে কি দিয়ে লগিন করেছে SocialMedia না হাতে লিখে -->
<div class="col-6 offset-3">
<?php if(session('status')): ?> 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
<?php if($errors->all()): ?>
					<div class="alert alert-danger" role="alert">
						
				
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php endif; ?>

    <?php if(Auth::User()->password == 'SocialAcount'): ?>
    <form action="<?php echo e(url('set/password')); ?>" method="post">
               <?php echo csrf_field(); ?>

               <div class="form-group">
                  <label>New Password</label>
                  <input type="password" class="form-control" name="newpassword" placeholder="Enter Your Password" value="<?php echo e(old('newpassword')); ?>">

                  <label>Confirm Password</label>
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Enter Your Confirm Password" value="<?php echo e(old('confirmpassword')); ?>">

               </div>
               
              
          <button type="submit" class="btn btn-info">Set Password</button>
            </form>
    <?php else: ?>
    <?php if(session('status')): ?> 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>

    <?php if($errors->all()): ?>
					<div class="alert alert-danger" role="alert">
						
				
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php endif; ?>
    <form action="<?php echo e(url('Change/password')); ?>" method="post">
               <?php echo csrf_field(); ?>

               <div class="form-group">
               <label>old Password</label>
                  <input type="password" class="form-control" name="oldpass" placeholder="Enter Your Password" value="<?php echo e(old('oldpass')); ?>">
                  <label>New Password</label>
                  <input type="password" class="form-control" name="newpassword" placeholder="Enter Your Password" value="<?php echo e(old('newpassword')); ?>">

                  <label>Confirm Password</label>
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Enter Your Confirm Password" value="<?php echo e(old('confirmpassword')); ?>">

               </div>
               
              
          <button type="submit" class="btn btn-info">Set Password</button>
            </form>
    <?php endif; ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim Uddin\Desktop\CITClass\josim\resources\views/customer/dashbord.blade.php ENDPATH**/ ?>