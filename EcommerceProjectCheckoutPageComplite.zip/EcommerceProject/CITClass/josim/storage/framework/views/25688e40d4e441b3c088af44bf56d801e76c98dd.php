<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row">
      <div class="col-lg-4">
         <div class="card px-3 py-3">
            <div class="card-header bg-success">
               Add Product Form
            </div>
            <!-- এর মাধমে success alert টা পাবো -->
            <?php if(session('status')): ?> 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <?php if($errors->all()): ?>
            <div class="alert alert-danger">
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(url('/add/product/insert')); ?>" method="post" enctype="multipart/form-data">
               <!--  <?php echo e(url('/add/product/insert')); ?> এটা Route থেকে আসছে -->
               <!-- ফরমের ডাটা ডাটাবেসে পাঠাইতে হলে <?php echo csrf_field(); ?> লিখতেই হবে  -->
               <?php echo csrf_field(); ?>

               <div class="form-group">
                  <label>Select Category</label>
                  <select class="form-control" name="categoryselectid">
                  <option class="d-none" value="">--Select--</option>
               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_id); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
               </div>
               <div class="form-group">
                  <label>Product Name</label>
                  <input type="text" class="form-control" name="Product_Name_josim" placeholder="Enter Product Name" value="<?php echo e(old('Product_Name_josim')); ?>">
               </div>
               <div class="form-group">
                  <label>Product Description</label>
                  <textarea class="form-control" name="Product_Description" rows="3" placeholder="Enter Product Description"><?php echo e(old('Product_Description')); ?></textarea>
               </div>
               <div class="form-group">
                  <label>Product Price</label>
                  <input type="text" class="form-control" name="Product_Price" placeholder="Enter Product Price" value="<?php echo e(old('Product_Price')); ?>">
               </div>
               <div class="form-group">
                  <label>Product Quentity</label>
                  <input type="text" class="form-control" name="Product_Quentity" placeholder="Enter Product Quentity" value="<?php echo e(old('Product_Quentity')); ?>">
               </div>
               <div class="form-group">
                  <label>Product Alert Quentity</label>
                  <input type="text" class="form-control" name="Product_Alert_Quentity" placeholder="Enter Product Alert Quentity" value="<?php echo e(old('Product_Alert_Quentity')); ?>">
               </div>
               <!-- ছবি আপলোডের জনে এবং ফরমের উপরে enctype="multipart/form-data" -->

               <div class="form-group">
                  <label>Product Image</label>
                  <input type="file" class="form-control" name="Product_image">
               </div>

               <button type="submit" class="btn btn-info">Submit</button>
            </form>
         </div>
      </div>
      <div class="col-lg-8">
         <!-- এর মাধমে success alert টা পাবো -->
         <?php if(session('deletestatus')): ?> 
         <!-- status এটা addproductinsert Conroller থেকে আসছে -->
         <div class="alert alert-danger">
            <?php echo e(session('deletestatus')); ?>

         </div>
         <?php endif; ?>
         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>SL.NO</th>
                  <th>Category Name</th>
                  <th>Product_Name</th>
                  <th>Product_Description</th>
                  <th>Product_Price</th>
                  <th>Product_Quentity</th>
                  <th>Alert_Quentity</th>
                  <th>Product Image</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>
               <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
               <?php $__empty_1 = true; $__currentLoopData = $all_Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr>
                  <td><?php echo e($loop->index+1); ?></td>
                  <td><?php echo e($all_Product->relationtocategory->category_id); ?></td>
                  <td><?php echo e($all_Product->Product_Name); ?></td>
                  <!--   Description Limit করে দেওয়ার জনে -->
                  <td><?php echo e(Str::limit($all_Product->Product_Description, 20)); ?></td>
                  <td><?php echo e($all_Product->Product_Price); ?></td>
                  <td><?php echo e($all_Product->Product_Quentity); ?></td>
                  <td><?php echo e($all_Product->Product_Alert_Quentity); ?></td>
                  
                  <!-- ইমেজ আপলোড করার জনে -->

                  <td>
                  	<img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($all_Product->Product_image); ?>" alt="No Images Found" width="60">
                  </td>

                  <td>
                     <a href="<?php echo e(url('/delete/product')); ?>/<?php echo e($all_Product->id); ?>" class="btn btn-sm btn-danger">
                     Delete</a><br>
                     <hr>
                     <!-- ডাটা ইডিট করার জন্যে -->
                     <a href="<?php echo e(url('/edit/product')); ?>/<?php echo e($all_Product->id); ?>" class="btn btn-sm btn-info">
                     Edit</a>
                  </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
               <tr class="text-center">
                  <td colspan="6"> No Data Available</td>
               </tr>
               <?php endif; ?>
            </tbody>
         </table>
         <!-- পেজিনেশন দেওয়ার জনে এর জনে
            Controller এ  $all_Products = Product::orderBy('id','desc')->paginate(2);
            ->paginate(2); এটা আছে -->
         <?php echo e($all_Products->links()); ?>

         <!-- ডিলিট করা ডাটাগুলো দেখানোর জনে -->
         <h2 class="text-center">SHow SoftDelete Product</h2>
         <table class="table table-bordered mt-5">
            <thead>
               <tr>
                  <th>SL.NO</th>
                  <th>Product_Name</th>
                  <th>Product_Description</th>
                  <th>Product_Price</th>
                  <th>Product_Quentity</th>
                  <th>Alert_Quentity</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>
               <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
               <?php $__empty_1 = true; $__currentLoopData = $deteted_product_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deteted_product_show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr>
                  <td><?php echo e($loop->index+1); ?></td>
                  <td><?php echo e($deteted_product_show->Product_Name); ?></td>
                  <!--   Description Limit করে দেওয়ার জনে -->
                  <td><?php echo e(Str::limit($deteted_product_show->Product_Description, 20)); ?></td>
                  <td><?php echo e($deteted_product_show->Product_Price); ?></td>
                  <td><?php echo e($deteted_product_show->Product_Quentity); ?></td>
                  <td><?php echo e($deteted_product_show->Product_Alert_Quentity); ?></td>
                  <td>
                     <a href="<?php echo e(url('/restore/product')); ?>/<?php echo e($deteted_product_show->id); ?>" class="btn btn-sm btn-danger">
                     Restore</a><br>
                     <hr>
                     <!-- ডাটা ইডিট করার জন্যে -->
                     <a href="<?php echo e(url('/permantlyDelete/product')); ?>/<?php echo e($deteted_product_show->id); ?>" class="btn btn-sm btn-info">
                     Delete Parmently</a>
                  </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
               <tr class="text-center">
                  <td colspan="6"> No Data Available</td>
               </tr>
               <?php endif; ?>
            </tbody>
         </table>
         <!-- পেজিনেশন দেওয়ার জনে এর জনে
            Controller এ  $all_Products = Product::orderBy('id','desc')->paginate(2);
            ->paginate(2); এটা আছে -->
         <?php echo e($all_Products->links()); ?>

      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim Uddin\Desktop\CITClass\josim\resources\views/Product/AddNewProduct.blade.php ENDPATH**/ ?>