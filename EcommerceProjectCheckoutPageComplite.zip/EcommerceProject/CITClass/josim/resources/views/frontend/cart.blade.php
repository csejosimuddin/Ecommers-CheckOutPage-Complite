@extends('layouts.master')
@section('title','CartPage')
@section('content')
<div class="page-info-section page-info">
   <div class="container">
      <div class="site-breadcrumb">
         <a href="#">Home</a> /
         <a href="#">Sales</a> /
         <a href="#">Bags</a> /
         <span>Cart</span>
      </div>
      <img src="img/page-info-art.png" alt="" class="page-info-art">
   </div>
</div>
<div class="page-area cart-page spad">
   <div class="container">
      <div class="cart-table">
         <table>
            <thead>
               <tr>
                  <th class="product-th">Product</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th class="total-th">Total</th>
               </tr>
            </thead>
            <!-- এর মাধমে success alert টা পাবো -->
            @if(session('productstatus')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-danger">
               {{ session('productstatus') }}
            </div>
            @endif
            <!-- এর মাধমে success alert টা পাবো -->
            @if(session('zero')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-danger">
               {{ session('zero') }}
            </div>
            @endif
            <form action="{{ url('update/cart') }}" method="post">
               @csrf
               <tbody>

			   @php
				$subtotal = 0;
				@endphp

                  @foreach($cart_items as $cart_item)
                  <tr>
                     <td class="product-col">
                        <img src="{{ asset('uploads/product_photos')}}/{{ App\product::find($cart_item->product_id)->Product_image }}" alt="" width="50">
                        <div class="pc-title">
                           <h4>{{ App\product::find($cart_item->product_id)->Product_Name }}</h4>
                           <a href="{{ url('delete/from/cart') }}/{{ $cart_item->id }}">Delete Product</a> 
                           @if(App\product::find($cart_item->product_id)->Product_Quentity == 0)
                           <div class="alert alert-danger">
                              <h4>this product stock out please delete this</h4>
                           </div>
                           @endif
                        </div>
                     </td>
                     <td class="price-col">${{ App\product::find($cart_item->product_id)->Product_Price }}</td>
                     <td class="quy-col">
                        <div class="quy-input">
                           <span>Qty</span>
                           <input type="hidden" value="{{ $cart_item->product_id }}" name="product_id[]">
                           <input type="number" value="{{ $cart_item->product_quantity }}" name="product_quantity[]">
                        </div>
                     </td>
                     <td class="total-col">${{ (App\product::find($cart_item->product_id)->Product_Price)*($cart_item->product_quantity) }}</td>
					 <!-- সবাটোটাল যোগ করার জন্যে -->
					 <!-- $subtotal এটা যেখানেই বসাব সেখানেই টোটাল ফলাফলটা দেখাবে -->
					
					 @php
					 $subtotal = $subtotal + ((App\product::find($cart_item->product_id)->Product_Price)*($cart_item->product_quantity));
					 @endphp
                  </tr>
                  @endforeach
               </tbody>
         </table>
      </div>
      <div class="row cart-buttons">
      <div class="col-lg-5 col-md-5">
      <a href="{{ url('/') }}">
      <div class="site-btn btn-continue">Continue shooping</div>
      </a>
      </div>
      <div class="col-lg-7 col-md-7 text-lg-right text-left">
      <a href="{{ url('clear/cart') }}"><div class="site-btn btn-line btn-update">Clear Cart</div></a>
      <button type="submit" class="site-btn btn-line btn-update">Update Cart</button>
      </div>
      </form>
      </div>
   </div>
   <div class="card-warp">
      <div class="container">
         <div class="row">
            <div class="col-lg-4">
               <div class="shipping-info">
                  <h4>Shipping method</h4>
                  <p>Select the one you want</p>
                  <div class="shipping-chooes">
                     <div class="sc-item">
                        <input type="radio" name="sc" id="one">
                        <label for="one" id="sm_one">Next day delivery<span>$4.99</span></label>
                     </div>
                     <div class="sc-item">
                        <input type="radio" name="sc" id="two">
                        <label for="two" id="sm_two">Standard delivery<span>$1.99</span></label>
                     </div>
                     <div class="sc-item">
                        <input type="radio" name="sc" id="three">
                        <label for="three" id="sm_three">Personal Pickup<span>Free</span></label>
                     </div>
                  </div>
                  <h4>Cupon code</h4>
                  <p>Enter your cupone code</p>
                  <div class="cupon-input">
                     <input type="text" id="coupon_code_input_field">
                     <button class="site-btn" id="apply_btn">Apply</button>
                  </div>
               </div>
            </div>
            <div class="offset-lg-2 col-lg-6">
               <div class="cart-total-details">
                  <h4>Cart total</h4>
                  <p>Final Info</p>
                  <ul class="cart-total-card">
                     <li>Subtotal<span>${{ $subtotal }}</span></li>
                     <li>Shipping<span id="shipping_cost">Free</span></li>
                     <li>Descount Percentage({{ $coupon_percentage }}%)<span>{{ $subtotal*($coupon_percentage/100) }}</span></li>
                      <li class="total">Total<span id="total_amount_show">{{ $subtotal - ($subtotal*($coupon_percentage/100)) }}</span><span>$</span></li> 

                     <span id="total_amount" style="display:none">{{ $subtotal - ($subtotal*($coupon_percentage/100)) }}</span>
                  </ul>
               <!-- CheckOut Page এ এর টোটাল হিসাবকে পাঠানোর জনে -->
               <form action="{{ url('checkout') }}" method="post">
	               @csrf
                 
                  <input type="hidden" name="final_total_amount" value="{{ $subtotal - ($subtotal*($coupon_percentage/100)) }}">
               <button type="submit" class="site-btn btn-full">Process T০o Checkout</button>
               </form>

               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<section class="footer-top-section home-footer">
   <div class="container">
      <div class="row">
         <div class="col-lg-3 col-md-8 col-sm-12">
            <div class="footer-widget about-widget">
               <img src="img/logo.png" class="footer-logo" alt="">
               <p>Donec vitae purus nunc. Morbi faucibus erat sit amet congue mattis. Nullam fringilla faucibus urna, id dapibus erat iaculis ut. Integer ac sem.</p>
               <div class="cards">
                  <img src="img/cards/5.png" alt="">
                  <img src="img/cards/4.png" alt="">
                  <img src="img/cards/3.png" alt="">
                  <img src="img/cards/2.png" alt="">
                  <img src="img/cards/1.png" alt="">
               </div>
            </div>
         </div>
         <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="footer-widget">
               <h6 class="fw-title">usefull Links</h6>
               <ul>
                  <li><a href="#">Partners</a></li>
                  <li><a href="#">Bloggers</a></li>
                  <li><a href="#">Support</a></li>
                  <li><a href="#">Terms of Use</a></li>
                  <li><a href="#">Press</a></li>
               </ul>
            </div>
         </div>
         <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="footer-widget">
               <h6 class="fw-title">Sitemap</h6>
               <ul>
                  <li><a href="#">Partners</a></li>
                  <li><a href="#">Bloggers</a></li>
                  <li><a href="#">Support</a></li>
                  <li><a href="#">Terms of Use</a></li>
                  <li><a href="#">Press</a></li>
               </ul>
            </div>
         </div>
         <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="footer-widget">
               <h6 class="fw-title">Shipping & returns</h6>
               <ul>
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Track Orders</a></li>
                  <li><a href="#">Returns</a></li>
                  <li><a href="#">Jobs</a></li>
                  <li><a href="#">Shipping</a></li>
                  <li><a href="#">Blog</a></li>
               </ul>
            </div>
         </div>
         <div class="col-lg-2 col-md-4 col-sm-6">
            <div class="footer-widget">
               <h6 class="fw-title">Contact</h6>
               <div class="text-box">
                  <p>Your Company Ltd </p>
                  <p>1481 Creekside Lane Avila Beach, CA 93424, </p>
                  <p>+53 345 7953 32453</p>
                  <p><a href="https://preview.colorlib.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="87e8e1e1eee4e2c7fee8f2f5e2eae6eeeba9e4e8ea">[email&#160;protected]</a></p>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection

@section('footer_script')

<script type="text/javascript">
$(document).ready(function(){

   // Coupon এর জনে

	$('#apply_btn').click(function(){
		var coupon_code = $('#coupon_code_input_field').val();
		var link_to_go = "{{ url('/cart') }}/"+coupon_code;
	window.location.href = link_to_go;
	});

   // Shipping method এর জনে
   $('#sm_one').click(function(){
    $('#shipping_cost').html(4.99);
    var total_amount = parseFloat($('#total_amount').html())+parseFloat(4.99);
     $('#total_amount_show').html(total_amount);

   });

   $('#sm_two').click(function(){
    $('#shipping_cost').html(4.99);
    var total_amount = parseFloat($('#total_amount').html())+parseFloat(1.99);
     $('#total_amount_show').html(total_amount);

   });


   $('#sm_three').click(function(){
    $('#shipping_cost').html(4.99);
    var total_amount = parseFloat($('#total_amount').html())+parseFloat(0);
     $('#total_amount_show').html(total_amount);

   });

	
});	

</script>

@endsection