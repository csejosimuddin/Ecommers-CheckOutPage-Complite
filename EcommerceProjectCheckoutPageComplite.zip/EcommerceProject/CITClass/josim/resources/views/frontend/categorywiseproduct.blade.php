@extends('layouts.master')
@section('title','HomePAge')
@section('content')


<div class="page-info-section page-info">
<div class="container">
<div class="site-breadcrumb">
<a href="#">Home</a> /
<a href="#">Product</a> 
</div>
<img src="img/page-info-art.png" alt="" class="page-info-art">
</div>
</div>

<div class="container">
	<div class="row">
<div class="col-lg-12">
<h2 class="text-center mb-5 mt-5">Category or Archive Product Page</h2>
	
</div>
@foreach($products as $product)
	<div class="col-lg-3">

	     <div class="card mb-5">
		 <img src="{{ asset('uploads/product_photos') }}/{{ $product->Product_image }}" alt="">
        <div class="card-body">
         <h5 class="card-title">{{ $product->Product_Name }}</h5>
        <span>$1250</span>
         <button type="button" class="btn btn-outline-primary">Add To Cart</button>

         </div>

       </div>
		
	</div>
@endforeach


	
</div>
	
</div>







@endsection