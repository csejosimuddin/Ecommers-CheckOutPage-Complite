@extends('layouts.app')
@section('content')

<!-- কাস্টমার Dashbord এ ঢুকার পরে চেক হবে যে সে কি দিয়ে লগিন করেছে SocialMedia না হাতে লিখে -->
<div class="col-6 offset-3">
@if(session('status')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               {{ session('status') }}
            </div>
            @endif
@if($errors->all())
					<div class="alert alert-danger" role="alert">
						
				
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
						</div>
						@endif

    @if(Auth::User()->password == 'SocialAcount')
    <form action="{{ url('set/password') }}" method="post">
               @csrf

               <div class="form-group">
                  <label>New Password</label>
                  <input type="password" class="form-control" name="newpassword" placeholder="Enter Your Password" value="{{ old('newpassword') }}">

                  <label>Confirm Password</label>
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Enter Your Confirm Password" value="{{ old('confirmpassword') }}">

               </div>
               
              
          <button type="submit" class="btn btn-info">Set Password</button>
            </form>
    @else
    @if(session('status')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               {{ session('status') }}
            </div>
            @endif

    @if($errors->all())
					<div class="alert alert-danger" role="alert">
						
				
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
						</div>
						@endif
    <form action="{{ url('Change/password') }}" method="post">
               @csrf

               <div class="form-group">
               <label>old Password</label>
                  <input type="password" class="form-control" name="oldpass" placeholder="Enter Your Password" value="{{ old('oldpass') }}">
                  <label>New Password</label>
                  <input type="password" class="form-control" name="newpassword" placeholder="Enter Your Password" value="{{ old('newpassword') }}">

                  <label>Confirm Password</label>
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Enter Your Confirm Password" value="{{ old('confirmpassword') }}">

               </div>
               
              
          <button type="submit" class="btn btn-info">Set Password</button>
            </form>
    @endif
</div>


@endsection