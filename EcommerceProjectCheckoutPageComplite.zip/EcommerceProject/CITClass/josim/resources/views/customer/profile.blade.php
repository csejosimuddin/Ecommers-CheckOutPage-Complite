@extends('layouts.app')
@section('content')

<div class="col-8 offset-2">

@if(session('myprofileupdate')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               {{ session('myprofileupdate') }}
            </div>
            @endif


@if(App\CustomerModel::where('user_id', Auth::id())->exists())
Update Your Profile 

<form method="POST" action="{{ url('my/profile/update') }}">
 	@csrf
 <div class="form-group">
 	<label>Company</label>
 	<input type="text" class="form-control" name="Company" value="{{ old('Company') }}" placeholder="Enter Your Company Name">
</div>

 <div class="form-group">
 	<label>Address</label>
 	<textarea name="address" rows="5" class="form-control"></textarea>
</div>

<div class="form-group">
 	<label>Zip Code</label>
 	<input type="text" class="form-control" name="ZipCode" value="{{ old('ZipCode') }}" placeholder="Enter Your ZipCode ">
</div>


<div class="form-group">
 	<label>Phone Number</label>
 	<input type="text" class="form-control" name="PhoneNumber" value="{{ old('PhoneNumber') }}" placeholder="Enter Your ZipCode ">
</div>
<button type="submit" class="btn btn-success">Submit</butto
</form>

@else
<form method="POST" action="{{ url('my/profile/insert') }}">
 	@csrf
 <div class="form-group">
 	<label>Company</label>
 	<input type="text" class="form-control" name="Company" value="{{ old('Company') }}" placeholder="Enter Your Company Name">
</div>

 <div class="form-group">
 	<label>Address</label>
 	<textarea name="address" rows="5" class="form-control"></textarea>
</div>

<div class="form-group">
 	<label>Zip Code</label>
 	<input type="text" class="form-control" name="ZipCode" value="{{ old('ZipCode') }}" placeholder="Enter Your ZipCode ">
</div>


<div class="form-group">
 	<label>Phone Number</label>
 	<input type="text" class="form-control" name="PhoneNumber" value="{{ old('PhoneNumber') }}" placeholder="Enter Your ZipCode ">
</div>
<button type="submit" class="btn btn-success">Submit</button>

 </form>
@endif

</div>



@endsection