@extends('layouts.app')
@section('content')
<div class="container">
   <div class="row">
      <div class="col-lg-4">
         <div class="card px-3 py-3">
            <div class="card-header bg-success">
               Add Coupons 
            </div>

            </div>

            @if($errors->all())
            <div class="alert alert-danger">
               @foreach ($errors->all() as $error)
               <li>{{ $error }}</li>
               @endforeach
            </div>
            @endif

            <form action="{{ url('/add/coupon/insert') }}" method="post">
               @csrf

               <div class="form-group">
                  <label>Coupon Name</label>
                  <input type="text" class="form-control" name="coupon_name" placeholder="Enter Coupon Name" value="{{ old('coupon_name') }}">

                  <label>coupon percentage</label>
                  <input type="text" class="form-control" name="coupon_percentage" placeholder="Enter Ccoupon percentage" value="{{ old('coupon_percentage') }}">

                  <label>valid till</label>
                  <input type="date" class="form-control" name="valid_till" value="{{ old('valid_till') }}">

               </div>
               
              
               <button type="submit" class="btn btn-info">Submit</button>
            </form>
         </div>

         <div class="col-lg-8">

<table class="table table-bordered">
   <thead>
      <tr>
         <th>SL.NO</th>
         <th>Coupon Name</th>
         <th>coupon percentage</th>
         <th>valid till</th>
      </tr>
   </thead>
   <tbody>
   @foreach($couponDatashow as $couponDatashow)
   <tr>
   <td>{{ $loop->index+1 }}</td>
   <td>{{ $couponDatashow->coupon_name }}</td>
   <td>{{ $couponDatashow->coupon_percentage }}</td>
   <td>{{ $couponDatashow->valid_till }}</td>
     
   </tr>

   @endforeach
     
   </tbody>
</table>
</div>

      </div>
      
   </div>
</div>
@endsection