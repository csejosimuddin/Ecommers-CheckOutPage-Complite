<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use Hash;
use App\CustomerModel;
use Carbon\Carbon;



class CustomerController extends Controller
{
    function Customerhome(){
        return view('customer.dashbord');
    }

    // কাস্টমার Dashbord এ ঢুকার পরে চেক হবে যে সে কি দিয়ে লগিন করেছে SocialMedia না হাতে লিখে

    function setpassword(Request $request){
        $request->validate([
            'newpassword' => 'required|min:8',
            'confirmpassword' =>'required',
            'confirmpassword' => 'same:newpassword'

        ]);

User::find(Auth::id())->update([
    'password' => bcrypt($request->newpassword)
]);

    }

    // Hand Registation or password যদি socialmedia না হয় তাহলে

    function Changepassword(Request $request){

        if(Hash::check($request->oldpass, Auth::user()->password)){
            $request->validate([
            'newpassword' => 'required|min:8',
            'confirmpassword' => 'required',
            'confirmpassword' => 'same:newpassword'
        
            ]);
        User::find(Auth::id())->update([
        'password' => bcrypt($request->newpassword)
        ]);
        
        echo "New Password Set!";
        }
        
        
        else{
            return back()->with('status', 'Password vul!');
        }


    }


    // My Profile এর রাউট  জনে Controller এ কোড

function myprofile(){
return view('customer.profile');
}

// Customer Profile এর ডাটাকে ডাটাবেসে ঢুকানো

function myprofileinsert(Request $request){
    // print_r($request->all());
    // print_r(Auth::id());

    CustomerModel::insert([
        'user_id' => Auth::id(),
        'Company' => $request->Company,
        'address' => $request->address,
        'ZipCode' => $request->ZipCode,
        'PhoneNumber' => $request->PhoneNumber,
        'created_at' => Carbon::now()
    ]);
    return back();
}




function myprofileupdate(Request $request){
// print_r($request->all());
CustomerModel::where('user_id', Auth::id())->update([
    'Company' => $request->Company,
    'address' => $request->address,
    'ZipCode' => $request->ZipCode,
    'PhoneNumber' => $request->PhoneNumber,
    'created_at' => Carbon::now()
]);

return back()->with('myprofileupdate', 'Profile Update SuccessFully!');

}
















}
