<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\couponsModel;
use Carbon\Carbon;

class CouponController extends Controller
{
    function AddcouponView(){
        $couponDatashow = couponsModel::all();
        return view('Product.coupon.viewcopun',compact('couponDatashow'));
    }

    // coupon datebase এ যোগ করার জনে
    function addcouponinsert(Request $request){

        $request->validate([
            'coupon_name' => 'required|unique:coupons,coupon_name',
            'coupon_percentage' => 'required|numeric|min:1|max:99',   
        ]);

    if($request->valid_till >= Carbon::now()->format('Y-m-d')){

        couponsModel::insert([
            'coupon_name' => $request->coupon_name,
            'coupon_percentage' => $request->coupon_percentage,
            'valid_till' => $request->valid_till,
        ]);
        return back();

    }
    else{
        return back()->withErrors('Date is not Correct!');
    }

    }
    
       
    
}


