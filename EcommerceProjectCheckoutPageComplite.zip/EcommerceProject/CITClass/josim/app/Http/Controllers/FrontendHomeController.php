<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\categories;
use App\cart;
use App\User;
use App\couponsModel;
use Carbon\Carbon;

class FrontendHomeController extends Controller
{
 function Frontendhome(){
 	$premum_product = Product::orderBy('id','desc')->get();
	 $categories = categories::all();
	 $product = Product::all();
    return view('frontend.index',compact('premum_product','categories','product'));
 }


 

 // Click কারার পরে product Details Single Page এ দেখানোর জনে

function productDetails($product_id){
	$single_product_info = Product::findOrFail($product_id);
	// রিলেটেড Product দেখানোর জনে  single product এর id অনুযায়ী
	// category_p_id এটা product Table এর কলামের নাম

	$related_product = Product::where('id', '!=',$product_id)->where('category_p_id', $single_product_info->category_p_id)->get();

 return view('frontend.Show_Single_product',compact('single_product_info','related_product'));
}


// Click কারার পরে product Details Single Page এ দেখানোর জনে

// Route::get('/product/Details/{product_id}','FrontendHomeController@productDetails');

// যেখানে বা Single Product Open করার জনে যে পেজ ডিজাইন করা আছে সেখানে
// <h2>{{ $single_product_info->Product_Name }}</h2>
// single_product_info এটা Controller থেকে  Product_Name টেবিলের কলামের নাম


// ক্লিক করলেই যাতে single page এ খোলে তার জনে এই কোড

// <a href="{{ url('/product/Details') }}/{{ $premum_product->id }}">
// <figure>
//    <img src="{{ asset('/frontend/img/intro/1.jpg') }}" alt="#">
// </figure>
// </a>

// এবং Show_Single_product.blade পেজে কিছু কাজ আছে

// Category wise product show
 function categorywiseproduct($category_id){
	$products = product::where('category_p_id', $category_id)->get();
return view('frontend.categorywiseproduct', compact('products'));

 }

//  category_p_id এর product টেবিলের কলাম যার id category টেবিল থেকে আসছে integer

function addtocart($product_id){

	$ip_address = $_SERVER['REMOTE_ADDR'];


	if(cart::where('customer_ip', $ip_address)->where('product_id',$product_id)->exists()){

		//  exists() এর কাজ হছে Condition ঠিক হলে true return করবে আর ভুল হলে fales return করবে 

cart::where('customer_ip', $ip_address)->where('product_id',$product_id)->increment('product_quantity', 1);


}else{
	cart::insert([
	'customer_ip'=> $ip_address,
	'product_id'=> $product_id,
	'created_at'=> Carbon::now()
	]);

}

return back();


}



// Cart Page a Data Show করার জনে
// $coupon_name = "" এটা মানে নালেবল থাকলেও হবে না থাকলেও হবে
// $coupon_name != "" যদি coupon name থাকে

function cart($coupon_name = ""){

if($coupon_name != ""){
	if(couponsModel::where('coupon_name',$coupon_name)->exists()){
		if(Carbon::now()->format('Y-m-d') <= carbon::create(couponsModel::where('coupon_name',$coupon_name)->first()->valid_till)->format('Y-m-d') ){
		
			$coupon_percentage = couponsModel::where('coupon_name',$coupon_name)->first()->coupon_percentage;
			$cart_items = cart::where('customer_ip',$_SERVER["REMOTE_ADDR"])->get();
			return view('frontend.cart', compact('cart_items','coupon_percentage'));

		}
		else{
			echo "thik nai time";
		}

		 
	}


}
else{

	$coupon_percentage = 0;
	$cart_items = cart::where('customer_ip',$_SERVER["REMOTE_ADDR"])->get();
	return view('frontend.cart', compact('cart_items','coupon_percentage','coupon_percentage'));
}


	// $cart_items = cart::where('customer_ip',$_SERVER["REMOTE_ADDR"])->get();
	// return view('frontend.cart', compact('cart_items'));
}


function deletefromcart($cart_id){
	cart::find($cart_id)->delete();
	return back();
}


function clearcart(){
	cart::where('customer_ip', $_SERVER["REMOTE_ADDR"])->delete();
	return back();
}


// cart এর product গুলো কে আপডেট করার জনে

// 1.echo $product_id_value এটা product এর id টাকে ধরবে বা দেখাবে
// 2.echo $request->product_quantity[$product_id_key] এটা customer কয়টা product বাড়ালো তা দেখাবে


function updatecart(Request $request){

	foreach($request->product_id as $product_id_key => $product_id_value){
	echo $product_id_value."<br>";
	echo $request->product_quantity[$product_id_key]."<br>";
		if($request->product_quantity[$product_id_key] > 0){
			if($request->product_quantity[$product_id_key] <= Product::find($product_id_value)->Product_Quentity){
				cart::where('customer_ip', $_SERVER["REMOTE_ADDR"])->where('product_id', $product_id_value )->update([
					'product_quantity' => $request->product_quantity[$product_id_key]
				]);
			}
			else{
				return back()->with('productstatus', 'Product Not  Aviable!');
			}
		}
		else{
			return back()->with('zero', 'Product value not zero!');
		}


	}

	return back();

}

// Customer Login এর জনে

function registationview(){
return view('customer.login');
}


// Login Data Insert

function Customerinsert(Request $request){
// print_r($request->all());

User::insert([
	'name' => $request->name,
	'email' => $request->email,
	'role' => 2,
	'password' => bcrypt($request->password),
	'created_at' => Carbon::now()

	]);
return back();

}






}
