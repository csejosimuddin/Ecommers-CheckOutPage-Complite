<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class checkoutController extends Controller
{
   function checkout(Request $request){
    $final_total_amount = $request->final_total_amount;

   return view('frontend.checkout', compact('final_total_amount'));
   }
}
