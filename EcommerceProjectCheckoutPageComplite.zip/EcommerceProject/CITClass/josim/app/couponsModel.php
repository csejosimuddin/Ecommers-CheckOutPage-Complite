<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class couponsModel extends Model
{

    public $table='coupons';
    public $primaryKey='id';
    public $incrementing=true;
    public $keyType='int';
    public  $timestamps=true;
    
}
